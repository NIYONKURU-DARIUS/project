const mysql = require('mysql');
const express = require('express');
const bodyParser = require('body-parser');
const multer = require('multer');
const path = require('path');

const app = express();

app.use(express.json());
app.use(bodyParser.json());

// Set up MySQL connection
const db = mysql.createConnection({
    host: 'localhost',
    database: 'darius',
    user: 'root',
    password: '',
});

db.connect((err) => {
    if (err) throw err;
    console.log('Connected to the database');
});

// Create table if not exists
db.query(
    'CREATE TABLE IF NOT EXISTS Students (Student_id INT PRIMARY KEY AUTO_INCREMENT, name TEXT, age INT, grade TEXT, image TEXT)',
    (err) => {
        if (err) {
            console.log(err.message);
        } else {
            console.log("✅ Table 'students' is ready");
        }
    }
);

// Multer setup for handling image uploads
const storage = multer.diskStorage({
    destination: 'uploads/', // Folder to store images
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname)); // Rename file with timestamp
    },
});

const upload = multer({ storage });

// Serve uploaded images
app.use('/uploads', express.static('uploads'));

app.get("/welcome", (req, res) => {
    res.json({ message: "Welcome" });
});

app.delete("/delete/:id", (req, res) => {
    db.query("DELETE FROM students WHERE Student_id=?", [req.params.id], (err) => {
        if (err) return res.status(404).json({ message: "The user with that id is not found" });
        res.status(200).json({ message: "The user is deleted successfully" });
    });
});

app.get("/student/:id", (req, res) => {
    const { id } = req.params;
    db.query("SELECT * FROM students WHERE Student_id=?", [id], (err, user) => {
        if (err) res.status(404).json({ message: "The user with that id is not found" });
        res.status(200).json({ message: user });
    });
});

app.put("/student/:id", (req, res) => {
    const { id } = req.params;
    const { name } = req.body;
    db.query("UPDATE students SET name=? WHERE Student_id=?", [name, id], (err, user) => {
        if (err) res.status(404).json({ message: "The user with that id is not found" });
        res.status(200).json({ message: user });
    });
});

app.get("/students", (req, res) => {
    db.query("SELECT * FROM students", (err, data) => {
        if (err) throw err;
        res.json({ result: data });
    });
});

// Insert student with image upload
app.post("/insert", upload.single("image"), (req, res) => {
    const { name, age, grade } = req.body;
    const image = req.file ? req.file.filename : null; // Get uploaded file name

    db.query("INSERT INTO students (name, age, grade, image) VALUES (?, ?, ?, ?)", 
        [name, age, grade, image], 
        (err) => {
            if (err) throw err;
            res.json({ message: "Data is sent to students", imageURL: `http://localhost:3000/uploads/${image}` });
        }
    );
});

const PORT = 3000;
app.listen(PORT, (error) => {
    if (error) {
        console.log("Failed");
    } else {
        console.log(`🚀 Server running on http://localhost:${PORT}`);
    }
});
