const http= require('http')
const date=new Date();

const server=http.createServer((req,res) => {
    if(req.url==='/datetime'){
        res.writeHead(200, {'Content-Type': 'text/plain'});
        res.end(date.toString());
    }
   })
   const port=3000;
   server.listen(port,(error) => {
    if(error){
        console.log("there is problem with server")
    }else{
        console.log("server is listening on port 3000")
    }
   })