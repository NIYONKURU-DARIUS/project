const fs = require("fs");
const readline = require("readline");

const readlinnn= readline.createInterface({
    input: process.stdin,
    output: process.stdout,
})

console.log("Please nelson Enter something you want to be kept in the file!.:")
readlinnn.on("line", (input) => {
    if(input.toLowerCase()==='exit'){
        console.log("Nelson, Good bye!")
    }else{
        fs.appendFile('user-input.txt',input + "\n",(error)=>{
            if(error){
                console.error("The error is:",error)
            }else{
                console.log("mr.minister ! your input is saved in the file you told use to save in .")
            }
        })
    }
})