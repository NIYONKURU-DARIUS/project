var http=require('http')
var port=9000
var url=require('url');
let myServer=http.createServer(function(req,res){
    var entered=url.parse(req.url,true)
    var data=entered.query;
    res.end(JSON.stringify(data));
})
myServer.listen(port)