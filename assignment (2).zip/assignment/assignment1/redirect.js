const http= require('http')

const Nserver= http.createServer(function(req, res){
    if(req.url==='/google'){
        res.writeHead(301, {Location: 'https://www.google.com/'})
        res.end()
    }
})
const port=3667;
Nserver.listen(port);