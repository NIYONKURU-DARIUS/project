const http = require('http');

const NelsonServer= http.createServer((req,res)=>{
    const request=req.method
    const url=req.url
    console.log(request)
    console.log(url)

    res.writeHead(200,{'Content-type':'text/plain'})
    res.end("the nelson's request logged successfully !")
})

const port=8088
NelsonServer.listen(port, (error)=>{
    if(error) 
    {console.log("There is problem")}
    else{
        console.log(`Server is running at http://localhost:${port}`)  }
    
})