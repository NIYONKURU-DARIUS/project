

// Access the PATH environment variable
const pathVariable = process.env.PATH;

// Check if the variable exists
if (pathVariable) {
  console.log(`The value of PATH is: ${pathVariable}`);
} else {
  console.log('PATH is not set.');
}
