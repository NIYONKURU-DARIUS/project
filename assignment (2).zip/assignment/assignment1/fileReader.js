var http = require('http');
var fs = require('fs');
//create a server object for serving the requests to the specified path. 
var NelsonServer = http.createServer(function(input, output) {
    output.writeHead(200, { 'Content-type': 'text/plain' });

    fs.readFile('example.txt', function(error, data) {
        if (error) {
            // Log error and send a response to the client
            console.log("The file can't be accessed");
            output.writeHead(500, { 'Content-type': 'text/plain' });
            output.end('Error reading the file.');
        } else {
            // Send file content to the client
            output.end(data);
            console.log(data.toString())
        }
    });
});
//make start your made server to the given port i.e:9000
NelsonServer.listen(9000, function() {
    console.log('Server running at http://localhost:9000/');
});
