const http=require('http')
const url=require('url')
const users = new Set();


const server = http.createServer((req, res) => {

    const parsedUrl = url.parse(req.url, true);

    if (parsedUrl.pathname === '/login') {
        const name = parsedUrl.query.name;

        if (name) {
            if (users.has(name)) {
                res.writeHead(200, { 'Content-Type': 'text/plain' });
                res.end(`Welcome back, ${name}!`);
            } else {
                users.add(name);
                res.writeHead(200, { 'Content-Type': 'text/plain' });
                res.end(`Welcome, ${name}!`);
            }
        } else {
            res.writeHead(400, { 'Content-Type': 'text/plain' });
            res.end('Please provide a name. Example: /login?name=John');
        }
    } else {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('Route not found. Try /login?name=YourName');
    }
});

const port=5900

server.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});

