const http = require('http');


const jokes = [
    "Why don't scientists trust atoms? Because they make up everything!",
    "Why did the scarecrow win an award? Because he was outstanding in his field!",
    "I told my wife she should embrace her mistakes. She gave me a hug.",
    "Parallel lines have so much in common. Its a shame they'll never meet.",
    "Why do cows wear bells? Because their horns don't work!",
    "Why did the tomato turn red? It saw the salad dressing!",
    "Why don't scientists trust atoms? Because they make up everything!",
    "Why did the scarecrow win an award? Because he was outstanding in his field!",
    "I told my wife she should embrace her mistakes. She gave me a hug.",
];

const getRandomJoke = () => jokes[Math.floor(Math.random() * jokes.length)];


const server = http.createServer((req, res) => {
    if (req.url === '/joke') {
        const randomJoke = getRandomJoke();
        res.writeHead(200, { 'Content-Type': 'text/plain' });
        res.end(randomJoke);
    } else {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('Route not found. Try /joke');
    }
});


const PORT = 3000;
server.listen(PORT, () => {
    console.log(`Server is running at http://localhost:${PORT}`);
});
